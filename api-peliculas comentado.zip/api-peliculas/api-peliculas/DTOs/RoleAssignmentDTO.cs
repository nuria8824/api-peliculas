public class RoleAssignmentDTO
{
    // Nombre de usuario al que se le asignará el rol
    public string UserName { get; set; }

    // Nombre del rol que se asignará al usuario
    public string Role { get; set; }
}
