public class LoginDTO
{
    // Nombre de usuario del usuario que intenta iniciar sesión
    public string UserName { get; set; }

    // Contraseña del usuario para iniciar sesión
    public string Password { get; set; }
}
